<template>
  <div class="flex justify-center">
    <div class="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-nirvana-blue"></div>
  </div>
</template>
